#ifndef INTERFACE_H
#define INTERFACE_H
#include "t_datamap.h"

void start_interface();
_char spot_symbol(string p_symbol);

#endif // INTERFACE_H
